document.addEventListener("DOMContentLoaded", function() {
	
	const gameBoard = document.getElementById("game-board");
    const scoreElement = document.getElementById("score");
	const popup = document.getElementById("popup");
    const closePopupBtn = document.getElementById("close-popup");
    
    const gridSize = 16;
    const eggCount = 8;
    let clicks = 0;
    let eggsFound = 0;
	
	createBoard();
	placeEggs();	

    function createBoard() {
        for (let i = 0; i < gridSize * gridSize; i++) {
            const cell = document.createElement("div");
            cell.classList.add("cell");
            cell.addEventListener("click", onCellClick);
            gameBoard.appendChild(cell);
        }        	
    }

	function placeEggs() {
		for (let i = 0; i < eggCount; i++) {
			let eggPlaced = false;
			while (!eggPlaced) {
				const randomCell = Math.floor(Math.random() * gridSize * gridSize);
				const cell = gameBoard.children[randomCell];
				if (!cell.classList.contains("egg")) {
					const eggType = "egg" + (Math.floor(Math.random() * 4) + 1);
					cell.classList.add("egg", eggType);
					eggPlaced = true;
				}
			}
		}
	}

    function onCellClick(event) {
		clicks++;
		const cell = event.target;
		if (cell.classList.contains("egg")) {
			eggsFound++;
			cell.style.backgroundImage = cell.style.backgroundImage;
			cell.removeEventListener("click", onCellClick);
			setTimeout(() => {
				showPopup();
			}, 100);
		} else {
			cell.classList.add("clicked-grass");
		}
		scoreElement.textContent = `Clicks: ${clicks} | Eggs Found: ${eggsFound}`;

		if (eggsFound === eggCount) {
			setTimeout(() => {
				alert("Congratulations! You found all the eggs in " + clicks + " clicks.");
				location.reload();
			}, 100);
		}
	}

    function showPopup() {
        popup.classList.remove("hidden");
    }
	
	function closePopup() {
        popup.classList.add("hidden");
    }

    closePopupBtn.addEventListener("click", closePopup);
	
});
